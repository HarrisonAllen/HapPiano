import time, threading, os

'''
Sample file:
----
bpm:120
beat:4
name:C major scale
music:(C4,1/2) (D4,1/4) (E4,1/4) (F4,1/4) (G4,1/2) (C4|E4|G4,1) (,1/2)

----
Note: the trailing newline is necessary!!

Notes are represented in their octave scale (e.g. 'C4' is middle C)
Rests are represented without any notes passed in
Chords are notes separated by |

'''

def parse(filename):
	'''
	Given a music file, returns a song dictionary like this:
	{'bpm': 120          		#the bpm as an int
	 'beat': 4		     		#the number of beats per measure
	 'rate': 4					#which note gets the beat
	 'name': 'song name' 		#the name of the song
	 'chords': [({'C4'}),.5)] 	#a list of all of the chords in the song, in order. See parse_chords for more
	}

	'''
	#take all of the lines out of the file
	song_string_form = {}
	file = open(os.path.join('File_Parser',filename), 'r')
	for line in file:
		key, value = line[:-1].split(':')
		song_string_form[key] = value
	file.close()

	#parse all of the data into the appropriate form
	song = {}
	song['bpm'] = int(song_string_form['bpm'])
	song['beat'] = int(song_string_form['beat'])
	song['rate'] = int(song_string_form['rate'])
	song['name'] = song_string_form['name']
	song['tempo'] = song['bpm'] / 60.0 / song['rate']
	note_speed = song['bpm'] / 60.0   #how long a 'beat' is in real time
	chords = parse_chords(song_string_form['music'], note_speed, song['rate'])
	song['chords'] = chords
	return song

def parse_chords(music, note_speed, beat):
	'''
	Given a string of music, the length of a note in real time, and the
	number of beats per measure, generate a list of tuples of chords
	(represented as a set of strings of the note names in that chord)
	and	their duration, in seconds.

	>>> parse_chords("(C4,1/2) (D4,1/4) (C4|E4,1/4) (,1/2)", 2.0, 4)
	[({'C4'}, 1.0), ({'D4'}, 0.5), ({'C4','E4'}, 0.5), ({}, 1.0)]

	'''
	chord_chunks = music.split(' ')
	chord_list = []
	for chord in chord_chunks:
		chord_str, duration_str = chord[1:-1].split(',')
		#check for rest
		if len(chord_str) != 0:
			chord_notes = set(chord_str.split('|'))
		else:
			chord_notes = set()

		duration_args = duration_str.split('/')
		if len(duration_args) == 1: #any whole notes
			duration = float(duration_args[0])
		else:						#non-whole notes
			duration = float(duration_args[0])/float(duration_args[1])
		chord_list.append((chord_notes, duration / note_speed * beat))
	return chord_list

def input_thread(L):
	input()
	L.append(None)

class waitThread (threading.Thread):
	def __init__(self, L):
		threading.Thread.__init__(self)
		self.L = L

	def run(self):
		input()
		self.L.append(None)

def play(song):
	print('\nPress Enter to stop playing')
	L = []
	waiter = waitThread(L)
	waiter.start()

	print('Playing:', song['name'], 'in:')
	tempo = song['tempo']
	for i in range(song['beat'],0,-1):
		print(i,flush=True)
		time.sleep(tempo)
	print()
	for chord in song['chords']:
		notes = sorted(list(chord[0]))
		duration = chord[1]
		for i in notes:
			print(i,end=' ')
		print()

		current_time = time.time()
		while time.time() - current_time < duration:
			if L:
				print('Exiting...')
				return
	print('The end')
	print('Press Enter to continue')
	waiter.join()


def practice():
	print('\nPress Enter to stop practicing')
	print('Play as much as you like')
	L = []
	waiter = waitThread(L)
	waiter.start()
	while not L:
		pass
	print('Done practicing')

def convert_num_to_notes(string, duration):
	'''
	Given a string of numbers
	and a duration
	returns the note pairs as a string 
	>>>convert_num_to_notes('321','1/4')
	'(E4,1/4) (D4,1/4) (C4,1/4)'
	'''
	mapping = {
		'1': 'C4',
		'2': 'D4',
		'3': 'E4',
		'4': 'F4',
		'5': 'G4',
	}

	result = ''
	for i in string:
		result += '(%s,%s)' % (mapping[i],duration) + ' '
	return result[:-1]


available_files = (
	"Test Files/c major scale.txt",			#C4 to G4
	"Test Files/mary had a little lamb.txt",#simple song
	"Test Files/hot cross buns.txt",		#simple song
	"Test Files/cde song.txt",				#simple song
	"Test Files/rest test.txt",				#tests rests
	"Test Files/chord test.txt",			#tests all possible note combos

	#all of the 5 note pieces
	"Five Note Files/hot cross buns.txt",			#simple
	"Five Note Files/mary had a little lamb.txt",	#simple
	"Five Note Files/ode to joy.txt",				#less simple
	"Five Note Files/oranges and lemons.txt",		#less simple
	"Five Note Files/jingle bells.txt",				#hardest
)

three_note_files = {
	"Mary Had a Little Lamb": "Test Files/mary had a little lamb.txt",
	"Hot Cross Buns": "Test Files/hot cross buns.txt",
	"C-D-E Song": "Test Files/cde song.txt",
	"Rest Test": "Test Files/rest test.txt",
	"Chord Test": "Test Files/chord test.txt",
}

five_note_files = {
	"Hot Cross Buns": "Five Note Files/hot cross buns.txt",
	"Mary Had a Little Lamb": "Five Note Files/mary had a little lamb.txt",
	"Ode to Joy": "Five Note Files/ode to joy.txt",
	"Oranges and Lemons": "Five Note Files/oranges and lemons.txt",
	"Jingle Bells": "Five Note Files/jingle bells.txt",
}

three_note_song_names = [i for i in three_note_files]
three_note_songs = [parse(three_note_files[i]) for i in three_note_song_names]

##five_note_song_names = [i for i in five_note_files]
five_note_song_names = ["Hot Cross Buns","Mary Had a Little Lamb","Ode to Joy","Oranges and Lemons","Jingle Bells"]
five_note_songs = [parse(five_note_files[i]) for i in five_note_song_names]

def repl():
	print("Welcome! Type QUIT or press ctrl+z to exit.")
	while True:
		print("Please select a song to play:")
		for i in range(len(five_note_song_names)):
			print(i+1,") ",five_note_song_names[i],sep='')
		print('%d) Practice on your own' % (len(five_note_song_names) + 1))
		try:
			expr = input('in> ')
		except EOFError:
			expr = 'QUIT'
		if expr == 'QUIT':
			break
		try:
			if int(expr) == len(five_note_song_names) + 1:
				practice()
			else:
				song_to_play = int(expr) - 1
				play(five_note_songs[song_to_play])
		except:
			print('Invalid input, must be integer from 1-%d' % len(three_note_songs))
		print()
	print("Thanks for playing!")

if __name__ == "__main__":
	repl()
