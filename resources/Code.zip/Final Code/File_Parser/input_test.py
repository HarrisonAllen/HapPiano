import _thread, time, threading

def input_thread(L):
	input()
	L.append(None)

def do_print():
	L = []
	_thread.start_new_thread(input_thread, (L,))
	while True:
		time.sleep(.1)
		if L: break
		print(i)
		i += 1

class waitThread (threading.Thread):
	def __init__(self, L):
		threading.Thread.__init__(self)
		self.L = L

	def run(self):
		input()
		self.L.append(None)

def threading_print():
	L = []
	waiter = waitThread(L)
	start = time.time()
	time_to_wait = 10
	waiter.start()
	while time.time() - start < time_to_wait:
		if L:
			print('break statement')
			return
	print('delayed')