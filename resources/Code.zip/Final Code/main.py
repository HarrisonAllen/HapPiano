import board, busio, adafruit_mcp230xx, digitalio, time, os, pygame, time, threading, sys
import RPi.GPIO as GPIO
import File_Parser.file_parser as parser

#pygame for playing sounds
pygame.mixer.pre_init(buffer=512)
pygame.mixer.init()
Sound = pygame.mixer.Sound

#i2c for keys and gpio for servos
i2c = busio.I2C(board.SCL, board.SDA)
mcp = adafruit_mcp230xx.MCP23017(i2c, address=0x20)
GPIO.setmode(GPIO.BCM)
number_of_keys = 5
neutral_position, active_position = 1.5, 3.5
neutral_positions = [5,3,-1,1,-1]
active_positions = [6,5,1,2,3]
fadeout_time = 200

#setup the input pins for the keys
key_input_pins = set(mcp.get_pin(i) for i in range(number_of_keys))
for pin in key_input_pins:
    pin.direction = digitalio.Direction.INPUT
    pin.pull = digitalio.Pull.UP

#DO NOT enable GPIO2 or GPIO3, those do i2c!
GPIO.setmode(GPIO.BCM)
gpio_pins = set(i for i in range(4,4+number_of_keys))
for pin in gpio_pins:
    GPIO.setup(pin, GPIO.OUT)

#all of our fun mapping dictionaries
key_pressed = {}
servo_active = {}
key_to_servo = {}
servo_to_key = {}
servo_pwm = {}
sound_to_play = {}
key_wants_to_be_pressed = {}
key_to_name = {}
name_to_key = {}

#filenames
filenames = ['PIANO/Piano.mf.C4.wav','PIANO/Piano.mf.D4.wav','PIANO/Piano.mf.E4.wav','PIANO/Piano.mf.F4.wav','PIANO/Piano.mf.G4.wav',]
metronome_filename = 'Metronome/Tick.wav'
metronome_sound = Sound(metronome_filename)

#translates key numbers to names
num_to_name = {0: 'C4', 1: 'D4', 2: 'E4', 3: 'F4', 4: 'G4'}

#setup all of those dictionaries
for key_num, servo_num, file in zip(range(number_of_keys), range(4,4+number_of_keys), filenames):
    key_pin = mcp.get_pin(key_num)
    key_pin.direction = digitalio.Direction.INPUT
    key_pin.pull = digitalio.Pull.UP
    key_pressed[key_pin] = False

    servo_active[servo_num] = False
    GPIO.setup(servo_num, GPIO.OUT)
    servo_pwm[servo_num] = GPIO.PWM(servo_num, 50)
    servo_pwm[servo_num].start(neutral_position + neutral_positions[servo_num-4])

    key_to_servo[key_pin] = servo_num
    servo_to_key[servo_num] = key_pin
    sound_to_play[key_pin] = Sound(file)
    key_to_name[key_pin] = num_to_name[key_num]
    name_to_key[num_to_name[key_num]] = key_pin

sound_is_being_played = {}
for key in key_pressed:
    sound_is_being_played[key] = False
    key_wants_to_be_pressed[key] = False


def move_to_position(servo, position):
    '''
    Given a servo, move it to a certain position
    '''
    servo.ChangeDutyCycle(position)

def cleanup():
    '''
    Stop PWM and cleanup the GPIO, otherwise have to reboot PI!
    '''
    for pwm in servo_pwm.values():
        pwm.stop()
    GPIO.cleanup()

class play_thread (threading.Thread):
    '''
    A thread for playing a song, although I guess it doesn't have to be a thread...
    '''
    def __init__(self, song, feedback, delay):
        threading.Thread.__init__(self)
        self.song = song
        self.done = False
        self.feedback = feedback #tactile feedback?
        self.delay = delay #how long until feedback?
        
        self.notes = 0
        self.late_notes = 0
        self.early_release_notes = 0
        self.late_release_notes = 0

        self.total_delay = 0
        self.late_delay = 0
        self.latest_delay = 0
        self.early_release = 0
        self.late_release = 0
        
    def run(self):
        '''
        this lets a user play a song    
        '''

        #starts up the song with a metronome tick
        print('Playing:', self.song['name'], 'in:')
        tempo = self.song['bpm'] / 60.0 / self.song['rate']
        for i in range(self.song['beat'],0,-1):
            print(i,flush=True)
            metronome_sound.play()
            time.sleep(tempo)
        print()

        #now we get into playing the song
        for chord in self.song['chords']:
            self.notes += 1
            notes = sorted(list(chord[0]))
            for i in notes:
                print(i,end=' ')
            print()
            
            notes_to_play = set(notes)
            
            duration = chord[1]
            notes_all_hit = False
            start_time = time.time()
            #waits until exclusively the correct notes are pressed
            while not notes_all_hit:
                if feedback and time.time() - start_time > self.delay:
                    for i in notes_to_play:
                        servo = key_to_servo[name_to_key[i]]
                        servo_active[servo] = True
                        move_to_position(servo_pwm[servo],active_position + active_positions[servo-4])                      
                keys_being_pressed = set()
                for key in key_pressed:
                    if not key.value:
                        keys_being_pressed.add(key_to_name[key])
                notes_all_hit = keys_being_pressed == notes_to_play
                time.sleep(.01)
##
            #analyze how long it took to preass
            hit_time = time.time()
            time_to_hit = hit_time - start_time
            self.total_delay += time_to_hit
            if time_to_hit > self.song['tempo'] / 2.0:
                self.late_notes += 1
                self.late_delay += time_to_hit
                print('late',time_to_hit)
                if time_to_hit > self.latest_delay:
                    self.latest_delay = time_to_hit
            
            time_since_hit = time.time()
            ended_late = False
            #
            while notes_all_hit:
                keys_being_pressed = set()
                for key in key_pressed:
                    if not key.value:
                        keys_being_pressed.add(key_to_name[key])
                notes_all_hit = keys_being_pressed == notes_to_play
                time_since_hit = time.time()
                if time_since_hit - hit_time > duration:
                    for i in notes_to_play:
                        servo = key_to_servo[name_to_key[i]]
                        servo_active[servo] = False
                        move_to_position(servo_pwm[servo],neutral_position + neutral_positions[servo-4])   
                    ended_late = True
                time.sleep(.01)

            if not ended_late:
                for i in notes_to_play:
                    servo = key_to_servo[name_to_key[i]]
                    servo_active[servo] = False
                    move_to_position(servo_pwm[servo],neutral_position + neutral_positions[servo-4])   
            

            time_held = time_since_hit - hit_time
            duration_dif = duration - time_held
            if duration_dif > self.song['tempo'] / 2.0:
                self.early_release_notes += 1
                self.early_release += duration_dif
                print('early release',duration_dif)
            if duration_dif < -self.song['tempo'] / 2.0:
                self.late_release_notes += 1
                self.late_release += duration_dif
                print('late release',-duration_dif)

        missed_notes = self.late_notes

        print('Accuracy:')
        print('\tYou correctly hit a total of %d/%d notes for an accuracy of %d percent.'
              % ((self.notes - missed_notes),self.notes,((self.notes - missed_notes) * 100/self.notes)))
        print('\t%d/%d of your hits were late' % (self.late_notes,self.notes))
        print('\t%d/%d of your notes were released early' % (self.early_release_notes,self.notes))
        print('\t%d/%d of your notes were released late' % (self.late_release_notes,self.notes))

        print('Delay:')
        if self.notes > 0:
            print('\tYou took an average of %dms to hit the right keys' % int(self.total_delay * 1000 / self.notes))
        if self.late_notes > 0:
            print('\tYou were late by an average of %dms' % int(self.late_delay * 1000 / self.late_notes))
        print('\tYour latest delay was %dms' % int(self.latest_delay * 1000))

        print('Duration:')
        if self.early_release_notes > 0:
            print('\tYou released early by an average of %dms' % int(self.early_release * 1000 / self.early_release_notes))            
        if self.late_release_notes > 0:
            print('\tYou released late by an average of %dms' % int(self.late_release * 1000 / self.late_release_notes))
        self.done = True


class piano_thread (threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        try:
            while True:
                for key in key_pressed:
                    key_pressed[key] = not key.value
                    if not sound_is_being_played[key] and key_pressed[key]:
                        sound_to_play[key].play()
                        sound_is_being_played[key] = True
                    elif sound_is_being_played[key] and not key_pressed[key]:
                        sound_to_play[key].fadeout(fadeout_time)
                        sound_is_being_played[key] = False
                time.sleep(.01)
        except KeyboardInterrupt:
            cleanup()

class metronome_thread (threading.Thread):
    def __init__(self, tempo):
        threading.Thread.__init__(self)
        self.tempo = tempo
        self.play = True

    def run(self):
        while self.play:
            metronome_sound.play()
            current_time = time.time()
            while time.time() - current_time < self.tempo:
                pass
        

def repl(feedback, demo):
    print('===========================================')
    print("Welcome! Type QUIT or press ctrl+c to exit.")
    print()
    print('Starting piano with feedback','on' if feedback else 'off')
    print()
    delay = 0
    blocked_songs = 2 if not demo else 0
    while True:
        print("Please select a song to play:")
        for i in range(len(parser.five_note_song_names) - blocked_songs):
            print(i+1,") ",parser.five_note_song_names[i],sep='')
        print('%d) Practice on your own' % (len(parser.five_note_song_names) - blocked_songs + 1))
        try:
            expr = input('in> ')
        except EOFError:
            expr = 'QUIT'
        if expr == 'QUIT':
            break
        try:
            if expr == 'enable test1':
                blocked_songs = 1
            elif expr == 'enable test2':
                blocked_songs = 0
            elif expr == str(len(parser.five_note_song_names) - blocked_songs + 1):
                parser.practice()
            else:
                if expr == 'begin test1':
                    print('!==========Starting test1==========!')
                    delay = 0
                    song_to_play = 3
                    print('Press enter to start')
                    input()
                elif expr == 'begin test2':
                    print('!==========Starting test2==========!')
                    delay = 0
                    song_to_play = 4
                    print('Press enter to start')
                    input()
                else:
                    song_to_play = int(expr) - 1
                    if song_to_play > len(parser.five_note_songs) - blocked_songs:
                        raise IndexError
                play = play_thread(parser.five_note_songs[song_to_play], feedback, delay)
                play.start()
                while not play.done:
                    print(end='',flush=True)
                    time.sleep(.01)
                average_delay = (play.total_delay) / play.notes
                if average_delay > 1:
                    average_delay = 1
                average_delay -= parser.five_note_songs[song_to_play]['tempo']
                delay -= average_delay
                if delay < 0:
                    delay = 0
                print('Average delay:',average_delay)
                if not demo:
                    print('New delay:',delay)
                else:
                    delay = 0
                    print('Demo mode, no delay change.')
        except Exception as e:
##            print(e,type(e))
            print('Invalid input, must be integer from 1-%d' % (len(parser.five_note_song_names) - blocked_songs + 1))
        print()
    cleanup()
    print("Thanks for playing!")
    print('Please press ctrl-c to terminate the program.')

if __name__ == "__main__":
    piano = piano_thread()
    piano.start()
##    metronome = metronome_thread(.5)
##    metronome.start()
##    metronome.play = False
    print(sys.argv)
    demo = False
    if sys.argv[1] == 'True':
        feedback = True
    elif sys.argv[1] == 'Demo':
        feedback = True
        demo = True
    else:
        feedback = False
    repl(feedback, demo)
